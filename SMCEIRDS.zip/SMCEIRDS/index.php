<?
$_SESSION['isLoggedIn'] =
$_SESSION['isLoggedIn']??false;
?>