<?php
session_start();
include 'db_connect.php';


$login_error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMC Equipment System</title>
  <link rel="stylesheet" href="style/login.css">
</head>
<body class="login-page">
  <div class="container" id="container">

    <div class="welcome-panel">
      <h1>Welcome to SMC</h1>
      <p>Equipment Inventory, Request,<br> & Disposal System</p>
      <button id="loginBtn">Login</button>
    </div>

    <div class="login-panel">
      <div class="left">
        <h2>Welcome to SMC</h2>
        <p>Equipment Inventory, Request,<br> & Disposal System</p>
        <button id="backBtn">Back</button>
      </div>
      <div class="right">
        <h2>Login</h2>
        <form id="loginForm" action="login_process.php" method="POST">
          <input type="text" name="username" placeholder="Username" required>
          <input type="password" name="password" placeholder="Password" required>
          <button type="submit" class="login-submit">Login</button>
        </form>
        <?php if ($login_error): ?>
          <p class="error"><?= htmlspecialchars($login_error) ?></p>
        <?php endif; ?>
      </div>
    </div>

  </div>
  <script src="script.js"></script>
</body>
</html>
