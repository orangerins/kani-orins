<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$username || !$password) {
        $_SESSION['login_error'] = "Username and password are required";
        header("Location: login.php");
        exit;
    }

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT u.user_id, u.username, u.password, u.access_level
            FROM users u
            WHERE u.username = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();
        
        // For plain text password comparison (not recommended for production)
        if ($password === $row['password']) {
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['access_level'];
            $_SESSION['isLoggedIn'] = true;

            $stmt->close();
            $conn->close();

            // Redirect based on access_level
            switch($row['access_level']) {
                case "President":
                    header("Location: p_dashboard.php");
                    exit;
                case "VP-Finance":
                    header("Location: vp_dashboard.php");
                    exit;
                case "VP-Administrator":
                    header("Location: vp_administrator_dashboard.php");
                    exit;
                case "VP-Academics":
                    header("Location: vp_academics_dashboard.php");
                    exit;
                case "Secretary-Admin":
                    header("Location: secretaryadmin_dashboard.php");
                    exit;
                case "Secretary-Office":
                    header("Location: secretaryoffice_dashboard.php");
                    exit;
                case "Office Head":
                    header("Location: user_dashboard.php");
                    exit;
                default:
                    header("Location: dashboard.php");
                    exit;
            }
        } else {
            $stmt->close();
            $conn->close();
            $_SESSION['login_error'] = "Invalid username or password";
            header("Location: login.php");
            exit;
        }
    } else {
        $stmt->close();
        $conn->close();
        $_SESSION['login_error'] = "Invalid username or password";
        header("Location: login.php");
        exit;
    }
}
?>