<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($role_name);
$stmt->fetch();
$stmt->close();

if ($role_name !== 'President') {
    header("Location: login.php");
    exit;
}

$approved_count = $conn->query("SELECT COUNT(*) FROM request_supply WHERE status LIKE 'Approved%'")->fetch_row()[0];
$pending_count  = $conn->query("SELECT COUNT(*) FROM request_supply WHERE status = 'Pending'")->fetch_row()[0];
$declined_count = $conn->query("SELECT COUNT(*) FROM request_supply WHERE status = 'Rejected'")->fetch_row()[0];
$disposal_count = $conn->query("SELECT COUNT(*) FROM disposal")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>President Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-page">
  <div class="dashboard-container">
    
    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>President Dashboard</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="User" class="user-icon">
        <span><?= htmlspecialchars($role_name) ?></span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="p_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="p_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
        <li><a href="p_disposal.php"><img src="compartment/disposal.png" alt="Disposals"> <span>Disposals</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
       <h2>Overview</h2>
       <div class="cards">
          <div class="card approved">
            <h3>Total Approved Requests</h3>
            <p><?= $approved_count ?></p>
          </div>
          <div class="card pending">
            <h3>Pending for Review</h3>
            <p><?= $pending_count ?></p>
          </div>
          <div class="card declined">
            <h3>Declined</h3>
            <p><?= $declined_count ?></p>
          </div>
          <div class="card disposal">
            <h3>Disposal Reports</h3>
            <p><?= $disposal_count ?></p>
          </div>
        </div>
    </main>

  </div>
</body>
</html>
