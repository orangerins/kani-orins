<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>President Disposals</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="request-page">

  <div class="dashboard-container">
    
    <header class="topbar">
      <img src="logoname.png" alt="MySMC Logo" class="logo">
      <h1>President - Disposal Requests</h1>
      <div class="user-info">
        <img src="user.png" alt="President" class="user-icon">
        <span>President</span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="p_dashboard.html"><img src="dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="p_request.html"><img src="request.png" alt="Requests"> <span>Requests</span></a></li>
        <li class="active"><a href="p_disposal.html"><img src="disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.html"><img src="logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Pending Disposal Requests</h2>

      <div class="filter-container">
        <label for="statusFilter">Status:</label>
        <select id="statusFilter">
          <option value="all">All</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="declined">Declined</option>
        </select>

        <label for="dateFilter">Date:</label>
        <input type="date" id="dateFilter">
      </div>

      <table class="request-table">
        <thead>
          <tr>
            <th>Disposal ID</th>
            <th>User</th>
            <th>Item</th>
            <th>Reason</th>
            <th>Date Submitted</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="disposalList"></tbody>
      </table>
    </main>

  </div>

  <script src="script.js"></script>
</body>
</html>
