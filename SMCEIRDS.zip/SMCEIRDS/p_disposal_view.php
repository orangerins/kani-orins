<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Disposal Request Details</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="request-page">

  <div class="dashboard-container">
    <header class="topbar">
      <img src="logoname.png" alt="MySMC Logo" class="logo">
      <h1>Disposal Request Details</h1>
      <div class="user-info">
        <img src="user.png" alt="President" class="user-icon">
        <span>President</span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="p_dashboard.html"><img src="dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="p_request.html"><img src="request.png" alt="Requests"> <span>Requests</span></a></li>
        <li class="active"><a href="p_disposal.html"><img src="disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.html"><img src="logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Disposal Information</h2>
      <div id="disposalDetails">Loading...</div>
      <br>
      <button id="approveBtn" class="btn approve">Approve</button>
      <button id="declineBtn" class="btn decline">Decline</button>
      <br><br>
      <a href="p_disposal.html">Back</a>
    </main>
  </div>

  <script src="script.js"></script>
</body>
</html>
