<?php
include 'db_connect.php';

// Handle AJAX requests
if (isset($_POST['action']) || isset($_GET['action'])) {
    $action = isset($_POST['action']) ? $_POST['action'] : $_GET['action'];
    
    switch($action) {
        case 'load_president_requests':
            loadPresidentRequests($conn);
            exit;
        case 'filter_president_requests':
            filterPresidentRequests($conn);
            exit;
    }
}

function loadPresidentRequests($conn) {
    try {
        // Load ALL requests (Pending, Approved by President, Approved by VP, Rejected)
        $sql = "SELECT 
                    rs.request_id,
                    rt.type_name as request_type,
                    u.username,
                    rs.office,
                    rs.request_date,
                    rs.status,
                    rs.description
                FROM request_supply rs
                JOIN users u ON rs.user_id = u.user_id
                JOIN request_type rt ON rs.request_type_id = rt.request_type_id
                ORDER BY rs.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          $row['request_type'] . "~" . 
                          $row['username'] . "~" . 
                          $row['office'] . "~" . 
                          $row['request_date'] . "~" . 
                          $row['status'] . "~" . 
                          $row['description'];
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to load requests";
    }
}

function filterPresidentRequests($conn) {
    try {
        $status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
        $date_filter = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
        
        $sql = "SELECT 
                    rs.request_id,
                    rt.type_name as request_type,
                    u.username,
                    rs.office,
                    rs.request_date,
                    rs.status,
                    rs.description
                FROM request_supply rs
                JOIN users u ON rs.user_id = u.user_id
                JOIN request_type rt ON rs.request_type_id = rt.request_type_id
                WHERE 1=1";
        
        // Apply status filter
        if($status_filter != 'all') {
            if($status_filter == 'pending') {
                $sql .= " AND rs.status = 'Pending'";
            } elseif($status_filter == 'vp-approved') {
                $sql .= " AND rs.status = 'Approved by VP'";
            } elseif($status_filter == 'declined') {
                $sql .= " AND rs.status = 'Rejected'";
            }
        }
        
        // Apply date filter
        if(!empty($date_filter)) {
            $sql .= " AND DATE(rs.request_date) = '$date_filter'";
        }
        
        $sql .= " ORDER BY rs.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          $row['request_type'] . "~" . 
                          $row['username'] . "~" . 
                          $row['office'] . "~" . 
                          $row['request_date'] . "~" . 
                          $row['status'] . "~" . 
                          $row['description'];
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to filter requests";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>President Requests</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="p-request-page">

  <div class="dashboard-container">
    
    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>President - Requests</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="President" class="user-icon">
        <span>President</span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="p_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li class="active"><a href="p_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
        <li><a href="p_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Requests for Presidential Review</h2>

      <div class="filter-container">
        <label for="statusFilter">Status:</label>
        <select id="statusFilter">
          <option value="all">All</option>
          <option value="pending">Pending (Awaiting President Approval)</option>
          <option value="vp-approved">VP Approved</option>
          <option value="declined">Declined</option>
        </select>

        <label for="dateFilter">Date:</label>
        <input type="date" id="dateFilter">
      </div>

      <table class="request-table">
        <thead>
          <tr>
            <th>Request ID</th>
            <th>User</th>
            <th>Type</th>
            <th>Description</th>
            <th>Date Submitted</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="requestList">
          <tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">Loading requests...</td></tr>
        </tbody>
      </table>
    </main>

  </div>

  <script src="script.js"></script>
</body>
</html>