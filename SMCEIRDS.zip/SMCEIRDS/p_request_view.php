<?php
include 'db_connect.php';

// Handle AJAX requests
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    
    switch($action) {
        case 'get_president_request_details':
            getPresidentRequestDetails($conn);
            exit;
        case 'update_president_request_status':
            updatePresidentRequestStatus($conn);
            exit;
    }
}

function getPresidentRequestDetails($conn) {
    try {
        $request_id = intval($_POST['request_id']);
        
        if($request_id <= 0) {
            echo "error|Invalid request ID";
            return;
        }
        
        // Fixed query to match your ERD structure
        $sql = "SELECT 
                    rs.request_id,
                    rt.type_name as request_type,
                    u.username,
                    o.office_name,
                    rs.request_date,
                    rs.status,
                    rs.description,
                    e.equipment_name,
                    e.quantity
                FROM request_supply rs
                JOIN users u ON rs.user_id = u.user_id
                JOIN office o ON u.office_id = o.office_id
                JOIN request_type rt ON rs.request_type_id = rt.request_type_id
                LEFT JOIN equipment e ON rs.request_id = e.request_id
                WHERE rs.request_id = $request_id";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "success|" . 
                 $row['request_id'] . "~" . 
                 $row['request_type'] . "~" . 
                 $row['username'] . "~" . 
                 $row['office_name'] . "~" . 
                 $row['request_date'] . "~" . 
                 $row['status'] . "~" . 
                 $row['description'] . "~" . 
                 ($row['equipment_name'] ?? 'N/A') . "~" .
                 ($row['quantity'] ?? 'N/A');
        } else {
            echo "error|Request not found";
        }
    } catch (Exception $e) {
        echo "error|Failed to load request details: " . $e->getMessage();
    }
}

function updatePresidentRequestStatus($conn) {
    try {
        $request_id = intval($_POST['request_id']);
        $new_status = mysqli_real_escape_string($conn, trim($_POST['status']));
        
        if($request_id <= 0 || empty($new_status)) {
            echo "error|Invalid request data";
            return;
        }
        
        // Check current status - President can approve requests with "Pending" status (first approval)
        $check_sql = "SELECT status FROM request_supply WHERE request_id = $request_id";
        $check_result = mysqli_query($conn, $check_sql);
        $current_row = mysqli_fetch_assoc($check_result);
        
        if(!$current_row) {
            echo "error|Request not found";
            return;
        }
        
        $current_status = $current_row['status'];
        
        // President can only act on Pending requests (first approval)
        if($current_status != 'Pending') {
            echo "error|This request has already been processed (Status: $current_status)";
            return;
        }
        
        // Valid status transitions for President
        $valid_statuses = ['Approved by President', 'Rejected'];
        if(!in_array($new_status, $valid_statuses)) {
            echo "error|Invalid status option";
            return;
        }
        
        $sql = "UPDATE request_supply 
                SET status = '$new_status' 
                WHERE request_id = $request_id";
        
        if(mysqli_query($conn, $sql)) {
            echo "success|Request status updated successfully";
        } else {
            echo "error|Failed to update request status: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Database error occurred: " . $e->getMessage();
    }
}

// Get request ID from URL parameter
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Request</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="request-page">
  <div class="dashboard-container">
    
    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>President - Request Details</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="User" class="user-icon">
        <span>President</span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="p_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li class="active"><a href="p_request.php"><img src="compartment/request.png" alt="Request"> <span>Request</span></a></li>
        <li><a href="p_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Request Information</h2>

      <div id="requestDetails" class="request-details">
        <div style="text-align: center; padding: 40px; color: #666;">
          Loading request details...
        </div>
      </div>

      <div class="action-buttons" id="actionButtons" style="display: none;">
        <button id="approveBtn" class="btn approve">Approve</button>
        <button id="declineBtn" class="btn decline">Decline</button>
        <a href="p_request.php" class="btn" style="background-color: #6c757d; color: white; text-decoration: none;">Back</a>
      </div>
      
      <!-- Status update feedback -->
      <div id="statusMessage" style="display: none; margin: 20px 0; padding: 10px; border-radius: 5px;"></div>
    </main>

  </div>

  <script>
    // Store the request ID from PHP
    const PRESIDENT_REQUEST_ID = <?php echo $request_id; ?>;
    
    // This will be handled by the script.js file since it's already included
    console.log('President Request ID:', PRESIDENT_REQUEST_ID);
  </script>
  <script src="script.js"></script>
</body>
</html>