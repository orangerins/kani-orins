// Helper function - must be defined before it's used
function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

const container = document.getElementById("container");
const loginBtn = document.getElementById("loginBtn");
const backBtn = document.getElementById("backBtn");

if (loginBtn && backBtn && container) {
  loginBtn.addEventListener("click", () => {
    container.classList.add("show-login");
  });

  backBtn.addEventListener("click", () => {
    container.classList.remove("show-login");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const acc = document.querySelectorAll(".accordion");
  acc.forEach(button => {
    button.addEventListener("click", function () {
      this.classList.toggle("active");
      const panel = this.nextElementSibling;
      panel.classList.toggle("show");
    });
  });

  const officeSelect = document.getElementById("office");
  const deansChecklist = document.getElementById("deansChecklist");
  if (officeSelect) {
    officeSelect.addEventListener("change", function () {
      deansChecklist.style.display = this.value === "Dean's Office" ? "block" : "none";
    });
  }

  const openFormBtn = document.getElementById("openFormModal");
  const formModal = document.getElementById("requestModal");
  if (openFormBtn && formModal) {
    openFormBtn.addEventListener("click", () => {
      formModal.classList.add("show"); 
    });
  }

  document.querySelectorAll(".close").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-modal");
      const modal = document.getElementById(target);
      if (modal) modal.classList.remove("show"); 
    });
  });

  document.querySelectorAll(".view-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const modalId = btn.getAttribute("data-modal");
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.add("show");
    });
  });

  window.addEventListener("click", (e) => {
    document.querySelectorAll(".modal").forEach(m => {
      if (e.target === m) m.classList.remove("show");
    });
  });

  const equipmentForm = document.getElementById("equipmentForm");
  const cancelBtn = document.querySelector(".cancel-btn");
  if (cancelBtn && equipmentForm) {
    cancelBtn.addEventListener("click", () => {
      if (confirm("Are you sure you want to cancel? All inputs will be cleared.")) {
        equipmentForm.reset();
        if (deansChecklist) deansChecklist.style.display = "none";
        formModal.classList.remove("show"); 
      }
    });
  }

  if (equipmentForm) {
    equipmentForm.addEventListener("submit", function () {
      return confirm(
        'Once you click "Submit", you will no longer be able to modify the data you entered from the form.'
      );
    });
  }
});

// VP Inventory JavaScript
let inventory = [];
function loadInventory() {
    const formData = new FormData();
    formData.append('action', 'load');
    
    fetch('vp_inventory.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            inventory = [];
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    // Updated to handle: equipment_id~equipment_name~user_id~user_name~location~status~quantity
                    if (parts.length >= 7) {
                        inventory.push({
                            equipment_id: parts[0],
                            id: `INV${String(parts[0]).padStart(3, '0')}`,
                            name: parts[1],
                            user_id: parts[2],
                            user_name: parts[3],
                            location: parts[4],
                            status: parts[5],
                            quantity: parseInt(parts[6])
                        });
                    }
                });
            }
            renderInventory();
        } else {
            showNotification('Failed to load inventory', 'error');
        }
    })
    .catch(error => {
        showNotification('Error loading inventory', 'error');
    });
}

function loadBorrowedEquipment() {
    const formData = new FormData();
    formData.append('action', 'load_borrowed');
    
    fetch('vp_inventory.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const borrowedList = document.getElementById("borrowedList");
        if (!borrowedList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            borrowedList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    if (parts.length >= 5) {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>${parts[0]}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td><span class="status-badge status-approved">${parts[4]}</span></td>
                        `;
                        borrowedList.appendChild(row);
                    }
                });
            } else {
                borrowedList.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px; color: #666;">No borrowed equipment found</td></tr>';
            }
        } else {
            borrowedList.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px; color: #666;">No borrowed equipment found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error loading borrowed equipment:', error);
        const borrowedList = document.getElementById("borrowedList");
        if (borrowedList) {
            borrowedList.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px; color: #666;">Error loading borrowed equipment</td></tr>';
        }
    });
}

function renderInventory() {
    const inventoryList = document.getElementById("inventoryList");
    if (!inventoryList) return;
    
    inventoryList.innerHTML = "";
    
    if (inventory.length === 0) {
        inventoryList.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px; color: #666;">No inventory items found</td></tr>';
        return;
    }
    
    inventory.forEach((item, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.location || 'N/A'}</td>
            <td>${item.quantity}</td>
            <td><span class="status-badge status-${item.status.toLowerCase().replace(' ', '-')}">${item.status}</span></td>
            <td>
                <button class="btn edit" onclick="openEditModal(${index})">Edit</button>
                <button class="btn delete" onclick="deleteItem(${index})">Delete</button>
            </td>
        `;
        inventoryList.appendChild(row);
    });
}

function addItem(itemData) {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('equipment_name', itemData.name);
    formData.append('location', itemData.location);
    formData.append('status', itemData.status);
    formData.append('quantity', itemData.quantity);

    fetch('vp_inventory.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        if (data.startsWith('success|')) {
            showNotification('Item added successfully!', 'success');
            loadInventory();
            closeModal('addModal');
        } else {
            const errorMessage = data.replace('error|', '');
            showNotification(errorMessage, 'error');
        }
    })
    .catch(error => {
        showNotification('Error adding item', 'error');
    });
}

function editItem(itemData, equipment_id) {
    const formData = new FormData();
    formData.append('action', 'edit');
    formData.append('equipment_id', equipment_id);
    formData.append('equipment_name', itemData.name);
    formData.append('location', itemData.location);
    formData.append('status', itemData.status);
    formData.append('quantity', itemData.quantity);

    fetch('vp_inventory.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        if (data.startsWith('success|')) {
            showNotification('Item updated successfully!', 'success');
            loadInventory();
            closeModal('editModal');
        } else {
            const errorMessage = data.replace('error|', '');
            showNotification(errorMessage, 'error');
        }
    })
    .catch(error => {
        showNotification('Error updating item', 'error');
    });
}

function deleteItem(index) {
    if (confirm("Are you sure you want to delete this item?")) {
        const item = inventory[index];
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('equipment_id', item.equipment_id);

        fetch('vp_inventory.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            console.log('Delete response:', data);
            
            if (data.startsWith('success|')) {
                showNotification('Item deleted successfully!', 'success');
                loadInventory();
            } else if (data.startsWith('error|')) {
                const errorMessage = data.substring(6);
                showNotification(errorMessage, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Network error deleting item', 'error');
        });
    }
}

// President Request Functions
function loadPresidentRequests() {
    const formData = new FormData();
    formData.append('action', 'load_president_requests');
    
    fetch('p_request.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const requestList = document.getElementById('requestList');
        if (!requestList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            requestList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    // Updated: request_id~request_type~username~office_name~request_date~status~description
                    if (parts.length >= 7) {
                        const row = document.createElement("tr");
                        
                        let displayStatus = parts[5];
                        if (parts[5] === 'Pending') {
                            displayStatus = 'Pending';
                        } else if (parts[5] === 'Approved by President') {
                            displayStatus = 'Approved by President';
                        } else if (parts[5] === 'Approved by VP Finance') {
                            displayStatus = 'VP Finance Approved';
                        } else if (parts[5] === 'Approved by VP Administrator') {
                            displayStatus = 'VP Admin Approved';
                        } else if (parts[5] === 'Approved by VP Academics') {
                            displayStatus = 'VP Academics Approved';
                        } else if (parts[5] === 'Rejected') {
                            displayStatus = 'Declined';
                        }
                        
                        row.innerHTML = `
                            <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[6].substring(0, 50)}${parts[6].length > 50 ? '...' : ''}</td>
                            <td>${formatDate(parts[4])}</td>
                            <td><span class="status-badge status-${displayStatus.toLowerCase().replace(/\s+/g, '-')}">${displayStatus}</span></td>
                            <td>
                                <button class="btn" style="font-size: 11px; padding: 4px 8px; background-color: #4e6cff; color: white;" onclick="viewPresidentRequest(${parts[0]})">View</button>
                            </td>
                        `;
                        requestList.appendChild(row);
                    }
                });
            } else {
                requestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
            }
        } else {
            requestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error loading President requests:', error);
        const requestList = document.getElementById('requestList');
        if (requestList) {
            requestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">Error loading requests</td></tr>';
        }
    });
}

function filterPresidentRequests() {
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    
    const status = statusFilter ? statusFilter.value : 'all';
    const date = dateFilter ? dateFilter.value : '';
    
    let url = `p_request.php?action=filter_president_requests&status=${status}`;
    if (date) {
        url += `&date=${date}`;
    }
    
    fetch(url)
    .then(response => response.text())
    .then(data => {
        const requestList = document.getElementById('requestList');
        if (!requestList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            requestList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    if (parts.length >= 7) {
                        const row = document.createElement("tr");
                        
                        let displayStatus = parts[5];
                        if (parts[5] === 'Pending') {
                            displayStatus = 'Pending';
                        } else if (parts[5] === 'Approved by President') {
                            displayStatus = 'Approved';
                        } else if (parts[5] === 'Rejected') {
                            displayStatus = 'Declined';
                        }
                        
                        row.innerHTML = `
                            <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[6].substring(0, 50)}${parts[6].length > 50 ? '...' : ''}</td>
                            <td>${formatDate(parts[4])}</td>
                            <td><span class="status-badge status-${displayStatus.toLowerCase().replace(/\s+/g, '-')}">${displayStatus}</span></td>
                            <td>
                                <button class="btn" style="font-size: 11px; padding: 4px 8px; background-color: #4e6cff; color: white;" onclick="viewPresidentRequest(${parts[0]})">View</button>
                            </td>
                        `;
                        requestList.appendChild(row);
                    }
                });
            } else {
                requestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
            }
        } else {
            requestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error filtering President requests:', error);
    });
}

function viewPresidentRequest(requestId) {
    window.location.href = `p_request_view.php?id=${requestId}`;
}

function loadPresidentRequestDetails(requestId) {
    const formData = new FormData();
    formData.append('action', 'get_president_request_details');
    formData.append('request_id', requestId);
    
    fetch('p_request_view.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const container = document.getElementById('requestDetails');
        const actionButtons = document.getElementById('actionButtons');
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            const parts = results.split('~');
            
            if (parts.length >= 8) {
                let displayStatus = parts[5];
                if (parts[5] === 'Pending') {
                    displayStatus = 'Pending Presidential Approval';
                } else if (parts[5] === 'Approved by President') {
                    displayStatus = 'Approved by President';
                } else if (parts[5] === 'Rejected') {
                    displayStatus = 'Declined';
                }
                
                container.innerHTML = `
                    <div class="request-details">
                        <p><strong>Request ID:</strong> REQ${String(parts[0]).padStart(3, '0')}</p>
                        <p><strong>User:</strong> ${parts[2]}</p>
                        <p><strong>Office:</strong> ${parts[3]}</p>
                        <p><strong>Type:</strong> ${parts[1]}</p>
                        <p><strong>Equipment:</strong> ${parts[7]}</p>
                        <p><strong>Quantity:</strong> ${parts[8] || 'N/A'}</p>
                        <p><strong>Description:</strong> ${parts[6]}</p>
                        <p><strong>Date Submitted:</strong> ${formatDate(parts[4])}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-${displayStatus.toLowerCase().replace(/\s+/g, '-')}">${displayStatus}</span></p>
                    </div>
                `;
                
                if (parts[5] === 'Pending') {
                    actionButtons.style.display = 'block';
                    setupPresidentRequestActions(parts[0]);
                } else {
                    actionButtons.style.display = 'block';
                    const approveBtn = document.getElementById('approveBtn');
                    const declineBtn = document.getElementById('declineBtn');
                    if (approveBtn) approveBtn.style.display = 'none';
                    if (declineBtn) declineBtn.style.display = 'none';
                }
            }
        } else {
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">Request not found</div>';
        }
    })
    .catch(error => {
        console.error('Error loading President request details:', error);
        const container = document.getElementById('requestDetails');
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">Error loading request details</div>';
    });
}

function setupPresidentRequestActions(requestId) {
    const approveBtn = document.getElementById('approveBtn');
    const declineBtn = document.getElementById('declineBtn');
    
    if (approveBtn) {
        approveBtn.onclick = () => updatePresidentRequestStatus(requestId, 'Approved by President');
    }
    
    if (declineBtn) {
        declineBtn.onclick = () => updatePresidentRequestStatus(requestId, 'Rejected');
    }
}

function updatePresidentRequestStatus(requestId, status) {
    const actionText = status === 'Approved by President' ? 'approve' : 'decline';
    
    if (confirm(`Are you sure you want to ${actionText} this request?`)) {
        const formData = new FormData();
        formData.append('action', 'update_president_request_status');
        formData.append('request_id', requestId);
        formData.append('status', status);
        
        fetch('p_request_view.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            if (data.startsWith('success|')) {
                alert(`Request has been ${actionText}d successfully!`);
                window.location.href = 'p_request.php';
            } else {
                const errorMessage = data.replace('error|', '');
                alert(errorMessage);
            }
        })
        .catch(error => {
            console.error('Error updating President request status:', error);
            alert('Error updating request status');
        });
    }
}

function searchInventory(searchTerm) {
    if (!searchTerm.trim()) {
        loadInventory();
        return;
    }

    fetch(`vp_inventory.php?action=search&search=${encodeURIComponent(searchTerm)}`)
    .then(response => response.text())
    .then(data => {
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            inventory = [];
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    if (parts.length >= 7) {
                        inventory.push({
                            equipment_id: parts[0],
                            id: `INV${String(parts[0]).padStart(3, '0')}`,
                            name: parts[1],
                            user_id: parts[2],
                            user_name: parts[3],
                            location: parts[4],
                            status: parts[5],
                            quantity: parseInt(parts[6])
                        });
                    }
                });
            }
            renderInventory();
        }
    })
    .catch(error => {
        showNotification('Error searching inventory', 'error');
    });
}

function openEditModal(index) {
    const item = inventory[index];
    document.getElementById("editIndex").value = index;
    document.getElementById("editEquipmentId").value = item.equipment_id;
    document.getElementById("editItemId").value = item.id;
    document.getElementById("editItemName").value = item.name;
    document.getElementById("editLocation").value = item.location || '';
    document.getElementById("editQuantity").value = item.quantity;
    document.getElementById("editStatus").value = item.status;

    openModal("editModal");
}

function openModal(id) {
    document.getElementById(id).classList.add("show");
}

function closeModal(id) {
    document.getElementById(id).classList.remove("show");
}

function showNotification(message, type = "info") {
    let notification = document.getElementById("notification");
    if (!notification) {
        notification = document.createElement("div");
        notification.id = "notification";
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 1001;
            max-width: 300px;
            word-wrap: break-word;
        `;
        document.body.appendChild(notification);
    }

    const colors = {
        success: "#28a745",
        error: "#dc3545",
        warning: "#ffc107",
        info: "#17a2b8"
    };
    
    notification.style.backgroundColor = colors[type] || colors.info;
    notification.textContent = message;
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// VP Request Functions
function loadVpRequests() {
    const formData = new FormData();
    formData.append('action', 'load_requests');
    
    fetch('vp_request.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const vpRequestList = document.getElementById('vpRequestList');
        if (!vpRequestList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            vpRequestList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    // Updated: request_id~request_type~username~office_name~request_date~status~description
                    if (parts.length >= 7) {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[6].substring(0, 50)}${parts[6].length > 50 ? '...' : ''}</td>
                            <td>${formatDate(parts[4])}</td>
                            <td><span class="status-badge status-${parts[5].toLowerCase().replace(/\s+/g, '-')}">${parts[5]}</span></td>
                            <td>
                                <button class="btn" style="font-size: 11px; padding: 4px 8px; background-color: #4e6cff; color: white;" onclick="viewVpRequest(${parts[0]})">View</button>
                            </td>
                        `;
                        vpRequestList.appendChild(row);
                    }
                });
            } else {
                vpRequestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
            }
        } else {
            vpRequestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error loading VP requests:', error);
        const vpRequestList = document.getElementById('vpRequestList');
        if (vpRequestList) {
            vpRequestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">Error loading requests</td></tr>';
        }
    });
}

function filterVpRequests() {
    const statusFilter = document.getElementById('statusFilter');
    const dateFilter = document.getElementById('dateFilter');
    
    const status = statusFilter ? statusFilter.value : 'all';
    const date = dateFilter ? dateFilter.value : '';
    
    let url = `vp_request.php?action=filter_requests&status=${status}`;
    if (date) {
        url += `&date=${date}`;
    }
    
    fetch(url)
    .then(response => response.text())
    .then(data => {
        const vpRequestList = document.getElementById('vpRequestList');
        if (!vpRequestList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            vpRequestList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    if (parts.length >= 7) {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[6].substring(0, 50)}${parts[6].length > 50 ? '...' : ''}</td>
                            <td>${formatDate(parts[4])}</td>
                            <td><span class="status-badge status-${parts[5].toLowerCase().replace(/\s+/g, '-')}">${parts[5]}</span></td>
                            <td>
                                <button class="btn" style="font-size: 11px; padding: 4px 8px; background-color: #4e6cff; color: white;" onclick="viewVpRequest(${parts[0]})">View</button>
                            </td>
                        `;
                        vpRequestList.appendChild(row);
                    }
                });
            } else {
                vpRequestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
            }
        } else {
            vpRequestList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No requests found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error filtering VP requests:', error);
    });
}

function viewVpRequest(requestId) {
    window.location.href = `vp_request_view.php?id=${requestId}`;
}

// VP Request View Functions
function loadVpRequestDetails(requestId) {
    const formData = new FormData();
    formData.append('action', 'get_request_details');
    formData.append('request_id', requestId);
    
    fetch('vp_request_view.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const container = document.getElementById('requestDetailsContainer');
        const actionsContainer = document.getElementById('actionsContainer');
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            const parts = results.split('~');
            
           if (parts.length >= 9) {
                let displayStatus = parts[5];
                if (parts[5] === 'Approved by President') {
                    displayStatus = 'Awaiting VP Finance Approval';
                } else if (parts[5] === 'Approved by VP Finance') {
                    displayStatus = 'Approved by VP Finance';
                } else if (parts[5] === 'Approved by VP Administrator') {
                    displayStatus = 'Approved by VP Administrator';
                } else if (parts[5] === 'Approved by VP Academics') {
                    displayStatus = 'Approved by VP Academics';
                } else if (parts[5] === 'Rejected') {
                    displayStatus = 'Rejected';
                }
                
                container.innerHTML = `
                    <div class="request-details">
                        <p><strong>Request ID:</strong> REQ${String(parts[0]).padStart(3, '0')}</p>
                        <p><strong>User:</strong> ${parts[2]}</p>
                        <p><strong>Office:</strong> ${parts[3]}</p>
                        <p><strong>Type:</strong> ${parts[1]}</p>
                        <p><strong>Equipment:</strong> ${parts[7]}</p>
                        <p><strong>Quantity:</strong> ${parts[8] || 'N/A'}</p>
                        <p><strong>Description:</strong> ${parts[6]}</p>
                        <p><strong>Date Submitted:</strong> ${formatDate(parts[4])}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-${displayStatus.toLowerCase().replace(/\s+/g, '-')}">${displayStatus}</span></p>
                    </div>
                `;
                
                // Show action buttons only if request is "Approved by President"
                if (parts[5] === 'Approved by President') {
                    actionsContainer.style.display = 'block';
                    setupVpRequestActions(parts[0]);
                } else {
                    actionsContainer.style.display = 'block';
                    const approveBtn = document.getElementById('approveBtn');
                    const rejectBtn = document.getElementById('rejectBtn');
                    if (approveBtn) approveBtn.style.display = 'none';
                    if (rejectBtn) rejectBtn.style.display = 'none';
                }
            }
        } else {
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">Request not found</div>';
        }
    })
    .catch(error => {
        console.error('Error loading VP request details:', error);
        const container = document.getElementById('requestDetailsContainer');
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">Error loading request details</div>';
    });
}

function setupVpRequestActions(requestId) {
    const approveBtn = document.getElementById('approveBtn');
    const rejectBtn = document.getElementById('rejectBtn');
    
    if (approveBtn) {
        approveBtn.onclick = () => updateVpRequestStatus(requestId, 'Approved by VP Finance');
    }
    
    if (rejectBtn) {
        rejectBtn.onclick = () => updateVpRequestStatus(requestId, 'Rejected');
    }
}

function updateVpRequestStatus(requestId, status) {
    const actionText = status === 'Approved by VP Finance' ? 'approve' : 'reject';
    
    if (confirm(`Are you sure you want to ${actionText} this request?`)) {
        const formData = new FormData();
        formData.append('action', 'update_request_status');
        formData.append('request_id', requestId);
        formData.append('status', status);
        
        fetch('vp_request_view.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            if (data.startsWith('success|')) {
                alert(`Request has been ${actionText}ed successfully! Inventory has been updated.`);
                window.location.href = 'vp_request.php';
            } else {
                const errorMessage = data.replace('error|', '');
                alert(errorMessage);
            }
        })
        .catch(error => {
            console.error('Error updating VP request status:', error);
            alert('Error updating request status');
        });
    }
}

// VP Dashboard Functions
function loadDashboardStats() {
    const formData = new FormData();
    formData.append('action', 'load_dashboard_stats');
    
    fetch('vp_dashboard.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            const stats = results.split('~');
            
            if (stats.length >= 4) {
                document.getElementById('vpPending').textContent = stats[0];
                document.getElementById('vpApproved').textContent = stats[1];
                document.getElementById('vpDeclined').textContent = stats[2];
                document.getElementById('vpStocks').textContent = stats[3];
            }
        } else {
            // Set default values if error
            document.getElementById('vpPending').textContent = '0';
            document.getElementById('vpApproved').textContent = '0';
            document.getElementById('vpDeclined').textContent = '0';
            document.getElementById('vpStocks').textContent = '0';
        }
    })
    .catch(error => {
        console.error('Error loading dashboard stats:', error);
        // Set default values if error
        document.getElementById('vpPending').textContent = '0';
        document.getElementById('vpApproved').textContent = '0';
        document.getElementById('vpDeclined').textContent = '0';
        document.getElementById('vpStocks').textContent = '0';
    });
}

function loadRecentRequests() {
    const formData = new FormData();
    formData.append('action', 'load_recent_requests');
    
    fetch('vp_dashboard.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        const recentRequestsList = document.getElementById('recentRequestsList');
        if (!recentRequestsList) return;
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            recentRequestsList.innerHTML = "";
            
            if (results) {
                const items = results.split('|');
                items.forEach((item) => {
                    const parts = item.split('~');
                    if (parts.length >= 7) {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                            <td>${parts[1]}</td>
                            <td>${parts[2]}</td>
                            <td>${parts[3]}</td>
                            <td>${formatDate(parts[4])}</td>
                            <td><span class="status-badge status-${parts[5].toLowerCase().replace(/\s+/g, '-')}">${parts[5]}</span></td>
                            <td>
                                <button class="btn view" style="font-size: 11px; padding: 4px 8px;" onclick="viewRequest(${parts[0]})">View</button>
                            </td>
                        `;
                        recentRequestsList.appendChild(row);
                    }
                });
            } else {
                recentRequestsList.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">No recent requests found</td></tr>';
            }
        } else {
            recentRequestsList.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">No recent requests found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error loading recent requests:', error);
        const recentRequestsList = document.getElementById('recentRequestsList');
        if (recentRequestsList) {
            recentRequestsList.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">Error loading recent requests</td></tr>';
        }
    });
}

function viewRequest(requestId) {
    // Redirect to the request view page
    window.location.href = `vp_request_view.php?id=${requestId}`;
}

// VP History Functions
function loadEquipmentHistory() {
    const formData = new FormData();
    formData.append('action', 'load_equipment_history');
    
    fetch('vp_history.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log('History data received:', data);
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            displayHistoryData(results);
        } else if (data.startsWith('error|')) {
            const errorMessage = data.substring(6);
            console.error('Server error:', errorMessage);
            document.getElementById('historyList').innerHTML = 
                `<tr><td colspan="8" style="text-align: center; padding: 40px; color: #f00;">Error: ${errorMessage}</td></tr>`;
        } else {
            document.getElementById('historyList').innerHTML = 
                '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No equipment request history found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error loading equipment history:', error);
        document.getElementById('historyList').innerHTML = 
            '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #f00;">Network error loading equipment history</td></tr>';
    });
}

function filterEquipmentHistory() {
    const statusFilter = document.getElementById('statusFilter');
    const typeFilter = document.getElementById('typeFilter');
    const dateFilter = document.getElementById('dateFilter');
    
    const status = statusFilter ? statusFilter.value : 'all';
    const type = typeFilter ? typeFilter.value : 'all';
    const date = dateFilter ? dateFilter.value : '';
    
    let url = `vp_history.php?action=filter_equipment_history&status=${encodeURIComponent(status)}&type=${encodeURIComponent(type)}`;
    if (date) {
        url += `&date=${encodeURIComponent(date)}`;
    }
    
    console.log('Filtering with URL:', url);
    
    fetch(url)
    .then(response => response.text())
    .then(data => {
        console.log('Filter data received:', data);
        
        if (data.startsWith('success|')) {
            const results = data.substring(8);
            displayHistoryData(results);
        } else if (data.startsWith('error|')) {
            const errorMessage = data.substring(6);
            console.error('Filter error:', errorMessage);
            document.getElementById('historyList').innerHTML = 
                `<tr><td colspan="8" style="text-align: center; padding: 40px; color: #f00;">Error: ${errorMessage}</td></tr>`;
        } else {
            document.getElementById('historyList').innerHTML = 
                '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No equipment request history found</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error filtering equipment history:', error);
        document.getElementById('historyList').innerHTML = 
            '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #f00;">Network error filtering equipment history</td></tr>';
    });
}

function displayHistoryData(results) {
    const historyList = document.getElementById('historyList');
    if (!historyList) {
        console.error('historyList element not found');
        return;
    }
    
    historyList.innerHTML = "";
    
    if (results && results.trim()) {
        const items = results.split('|');
        console.log('Processing items:', items.length);
        
        items.forEach((item, index) => {
            if (item.trim()) {
                const parts = item.split('~');
                console.log(`Item ${index}:`, parts);
                
                // Updated: request_id~equipment_name~requested_by~office_name~request_date~request_status~request_type~quantity
                if (parts.length >= 8) {
                    const row = document.createElement("tr");
                    
                    // Format the status for CSS class
                    const statusClass = parts[5].toLowerCase().replace(/\s+/g, '-');
                    
                    row.innerHTML = `
                        <td>REQ${String(parts[0]).padStart(3, '0')}</td>
                        <td>${parts[1]}</td>
                        <td>${parts[2]}</td>
                        <td>${parts[3]}</td>
                        <td>${parts[6]}</td>
                        <td>${parts[7]}</td>
                        <td>${formatDate(parts[4])}</td>
                        <td><span class="status-badge status-${statusClass}">${parts[5]}</span></td>
                    `;
                    historyList.appendChild(row);
                } else {
                    console.warn(`Item ${index} has insufficient parts:`, parts);
                }
            }
        });
        
        if (historyList.children.length === 0) {
            historyList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No valid equipment request history found</td></tr>';
        }
    } else {
        historyList.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">No equipment request history found</td></tr>';
    }
}

// PAGE INITIALIZATION - ALL PAGES
document.addEventListener("DOMContentLoaded", () => {
    
    // PRESIDENT REQUEST PAGE
    if (document.body.classList.contains('p-request-page')) {
        console.log('President Request page detected, initializing...');
        loadPresidentRequests();
        
        const statusFilter = document.getElementById('statusFilter');
        const dateFilter = document.getElementById('dateFilter');
        
        if (statusFilter) {
            statusFilter.addEventListener('change', filterPresidentRequests);
        }
        if (dateFilter) {
            dateFilter.addEventListener('change', filterPresidentRequests);
        }
        
        console.log('President Request page initialized');
    }
    
    // VP REQUEST PAGE
    if (document.body.classList.contains('vp-request-page')) {
        console.log('VP Request page detected, initializing...');
        loadVpRequests();
        
        const statusFilter = document.getElementById('statusFilter');
        const dateFilter = document.getElementById('dateFilter');
        
        if (statusFilter) {
            statusFilter.addEventListener('change', filterVpRequests);
        }
        if (dateFilter) {
            dateFilter.addEventListener('change', filterVpRequests);
        }
        
        console.log('VP Request page initialized');
    }
    
    // VP HISTORY PAGE
    if (document.body.classList.contains('vp-history-page')) {
        console.log('VP History page detected, initializing...');
        loadEquipmentHistory();
        
        const applyFilterBtn = document.getElementById('applyFilter');
        const statusFilter = document.getElementById('statusFilter');
        const typeFilter = document.getElementById('typeFilter');
        const dateFilter = document.getElementById('dateFilter');
        
        if (applyFilterBtn) {
            applyFilterBtn.addEventListener('click', filterEquipmentHistory);
        }
        if (statusFilter) {
            statusFilter.addEventListener('change', filterEquipmentHistory);
        }
        if (typeFilter) {
            typeFilter.addEventListener('change', filterEquipmentHistory);
        }
        if (dateFilter) {
            dateFilter.addEventListener('change', filterEquipmentHistory);
        }
        
        console.log('VP History page initialized');
    }
    
    // VP INVENTORY PAGE
    if (document.body.classList.contains('vp-inventory-page')) {
        console.log('VP Inventory page detected, initializing...');
        loadInventory();
        loadBorrowedEquipment();
        console.log('VP Inventory page initialized');
    }
    
    // VP DASHBOARD PAGE
    if (document.body.classList.contains('vp-dashboard-page')) {
        console.log('VP Dashboard page detected, initializing...');
        loadDashboardStats();
        loadRecentRequests();
        console.log('VP Dashboard page initialized');
    }
    
    // PRESIDENT REQUEST VIEW PAGE
    if (typeof PRESIDENT_REQUEST_ID !== 'undefined' && PRESIDENT_REQUEST_ID > 0) {
        console.log('Loading president request details for ID:', PRESIDENT_REQUEST_ID);
        loadPresidentRequestDetails(PRESIDENT_REQUEST_ID);
    }
    
    // VP REQUEST VIEW PAGE
    if (typeof REQUEST_ID !== 'undefined' && REQUEST_ID > 0) {
        console.log('Loading VP request details for ID:', REQUEST_ID);
        loadVpRequestDetails(REQUEST_ID);
    }
});