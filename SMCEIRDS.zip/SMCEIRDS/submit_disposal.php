<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipment_id = $_POST['equipment_id'] ?? null;
    $reason = $_POST['reason'] ?? null; 
    $dateDisposed = $_POST['dateDisposed'] ?? null;
    $user_id = $_SESSION['user_id'];

    if (empty($equipment_id) || empty($reason) || empty($dateDisposed)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: user_disposal.php");
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO disposal (equipment_id, user_id, disposal_date, notes, status)
        VALUES (?, ?, ?, ?, 'Pending')
    ");
    $stmt->bind_param("iiss", $equipment_id, $user_id, $dateDisposed, $reason);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Disposal request submitted successfully.";
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header("Location: user_disposal.php");
    exit;
}
?>