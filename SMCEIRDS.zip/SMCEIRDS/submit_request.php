<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id']; 
    $requestTypeName = $_POST['requestType'];
    $availableEquipment = $_POST['availableEquipment'] ?? null;
    $description = $_POST['description'];
    $dateRequested = $_POST['dateRequested'];
    $quantity = (int)($_POST['quantity'] ?? 1);

    $validTypes = ['Borrow','Purchase','Repair','Maintenance'];

    if (!in_array($requestTypeName, $validTypes)) {
        $_SESSION['error'] = "Invalid request type.";
        header("Location: user_request.php");
        exit;
    }

    // Get request_type_id from request_type table
    $stmt = $conn->prepare("SELECT request_type_id FROM request_type WHERE type_name = ?");
    $stmt->bind_param("s", $requestTypeName);
    $stmt->execute();
    $stmt->bind_result($request_type_id);
    $stmt->fetch();
    $stmt->close();

    if (!$request_type_id) {
        $_SESSION['error'] = "Request type not found in DB.";
        header("Location: user_request.php");
        exit;
    }

    // Get user's office_id
    $stmt = $conn->prepare("SELECT office_id FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($office_id);
    $stmt->fetch();
    $stmt->close();

    if (!$office_id) {
        $_SESSION['error'] = "User office not found.";
        header("Location: user_request.php");
        exit;
    }

    // Insert into request table (changed from request_supply)
    $stmt = $conn->prepare("INSERT INTO request (user_id, request_type_id, office_id, request_date, status, description) VALUES (?, ?, ?, ?, 'Pending', ?)");
    $stmt->bind_param("iiiss", $user_id, $request_type_id, $office_id, $dateRequested, $description);

    if ($stmt->execute()) {
        $request_id = $stmt->insert_id;
        $stmt->close();

        // Insert into request_item table for quantity tracking
        if ($quantity > 0) {
            $stmt2 = $conn->prepare("INSERT INTO request_item (request_id, equipment_id, quantity) VALUES (?, NULL, ?)");
            $stmt2->bind_param("ii", $request_id, $quantity);
            $stmt2->execute();
            $stmt2->close();
        }

        // Insert into equipment table if equipment is selected
        if (!empty($availableEquipment)) {
            $stmt3 = $conn->prepare("INSERT INTO equipment (equipment_name, location, user_id, status, quantity) VALUES (?, '', ?, 'Available', ?)");
            $stmt3->bind_param("sii", $availableEquipment, $user_id, $quantity);
            
            if (!$stmt3->execute()) {
                $_SESSION['error'] = "Request submitted but failed to add equipment details.";
            }
            $stmt3->close();
        }

        $_SESSION['success'] = "Request submitted successfully! Pending approval from President.";
        header("Location: user_request.php");
        exit;
    } else {
        $_SESSION['error'] = "Failed to submit request.";
        header("Location: user_request.php");
        exit;
    }
    
    $conn->close();
}
?>