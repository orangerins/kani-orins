<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$approved = $pending = $declined = $disposal = 0;

// Count approved requests (changed from request_supply to request)
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM request WHERE user_id = ? AND (status = 'Approved by President' OR status LIKE 'Approved by VP%')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$approved = $row['count'];
$stmt->close();

// Count pending requests
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM request WHERE user_id = ? AND status = 'Pending'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$pending = $row['count'];
$stmt->close();

// Count rejected requests
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM request WHERE user_id = ? AND status = 'Rejected'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$declined = $row['count'];
$stmt->close();

// Count disposal requests
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM disposal WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$disposal = $row['count'];
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Dashboard</title>
  <link rel="stylesheet" href="style/dashboard.css">
</head>
<body class="dashboard-page">
  <div class="dashboard-container">
    
    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Dashboard</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="User" class="user-icon">
        <span><?= htmlspecialchars($username) ?></span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li class="active"><a href="user_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="user_request.php"><img src="compartment/request.png" alt="Request"> <span>Request</span></a></li>
        <li><a href="user_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
       <h2>My Dashboard</h2>
       <div class="cards">
          <div class="card approved">
            <h3>Approved Requests</h3>
            <p><?= $approved ?></p>
          </div>
          <div class="card pending">
            <h3>Pending Requests</h3>
            <p><?= $pending ?></p>
          </div>
          <div class="card declined">
            <h3>Declined Requests</h3>
            <p><?= $declined ?></p>
          </div>
          <div class="card disposal">
            <h3>Disposal Requests</h3>
            <p><?= $disposal ?></p>
          </div>
        </div>
    </main>

  </div>
</body>
</html>