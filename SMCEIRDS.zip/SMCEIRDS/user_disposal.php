<?php
session_start();
include 'db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();

$sql = "
    SELECT d.disposal_id, d.disposal_date, d.notes, d.status,
           e.equipment_name AS equipment,
           u.username
    FROM disposal d
    JOIN equipment e ON d.equipment_id = e.equipment_id
    JOIN users u ON d.user_id = u.user_id
    WHERE d.user_id = ?
    ORDER BY d.disposal_date DESC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$disposals = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMC Disposal</title>
  <link rel="stylesheet" href="style/disposal.css">
</head>
<body class="disposal-page">

<div class="dashboard-container">

  <header class="topbar">
    <img src="logoname.png" alt="MySMC Logo" class="logo">
    <h1>Equipment Disposal</h1>
    <div class="user-info">
      <img src="user.png" alt="User" class="user-icon">
      <span><?= htmlspecialchars($user_name) ?></span>
    </div>
  </header>

  <aside class="sidebar">
    <ul>
      <li><a href="user_dashboard.php"><img src="dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
      <li><a href="user_request.php"><img src="request.png" alt="Request"> <span>Request</span></a></li>
      <li><a href="user_disposal.php" class="active"><img src="disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
      <li class="logout"><a href="logout.php"><img src="logout.png" alt="Logout"> <span>Logout</span></a></li>
    </ul>
  </aside>

  <main class="content">
    <div class="form-container">
      <h2>St. Michael’s College Equipment Disposal Form</h2>

      <?php if(isset($_SESSION['success'])): ?>
        <p class="success-msg"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></p>
      <?php elseif(isset($_SESSION['error'])): ?>
        <p class="error-msg"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></p>
      <?php endif; ?>

      <button id="openDisposalModal" class="submit-btn">+ New Disposal</button>

      <div id="disposalModal" class="modal">
        <div class="modal-content">
          <span class="close" data-modal="disposalModal">&times;</span>
          <h2>Equipment Disposal Form</h2>

          <form id="disposalForm" method="POST" action="submit_disposal.php">
            <label for="name">Name *</label>
            <input type="text" id="name" value="<?= htmlspecialchars($user_name) ?>" readonly>

            <label for="equipment_id">Equipment *</label>
            <select id="equipment_id" name="equipment_id">
              <option value="">-- Select Equipment --</option>
              <?php
                $eq = $conn->query("SELECT equipment_id, equipment_name FROM equipment ORDER BY equipment_name");
                while($row = $eq->fetch_assoc()) {
                  echo "<option value='".htmlspecialchars($row['equipment_id'])."'>".htmlspecialchars($row['equipment_name'])."</option>";
                }
              ?>
            </select>

            <label for="reason">Reason *</label>
            <textarea id="reason" name="reason" rows="3" required></textarea>

            <label for="dateDisposed">Date Disposed *</label>
            <input type="date" id="dateDisposed" name="dateDisposed" required>

            <div class="form-buttons">
              <button type="button" class="cancel-btn">Cancel</button>
              <button type="submit" class="submit-btn">Submit</button>
            </div>
          </form>
        </div>
      </div>

      <button class="accordion">Disposal History</button>
      <div class="panel">
        <ul id="disposalHistoryList">
          <?php foreach($disposals as $d): ?>
            <li data-status="<?= htmlspecialchars($d['status']) ?>">
              <span><strong><?= htmlspecialchars($d['username']) ?></strong> - 
                    <em><?= htmlspecialchars($d['equipment']) ?></em> - 
                    <?= htmlspecialchars($d['notes']) ?> 
                    (<?= date('M Y', strtotime($d['disposal_date'])) ?>) - 
                    <?= htmlspecialchars($d['status']) ?></span>
              <button class="view-btn" data-modal="disposalReport<?= $d['disposal_id'] ?>">View</button>
            </li>

            <div id="disposalReport<?= $d['disposal_id'] ?>" class="modal">
              <div class="modal-content">
                <span class="close" data-modal="disposalReport<?= $d['disposal_id'] ?>">&times;</span>
                <h2>Disposal Report</h2>
                <p><strong>Name:</strong> <?= htmlspecialchars($d['username']) ?></p>
                <p><strong>Equipment:</strong> <?= htmlspecialchars($d['equipment']) ?></p>
                <p><strong>Reason:</strong> <?= htmlspecialchars($d['notes']) ?></p>
                <p><strong>Status:</strong> <?= htmlspecialchars($d['status']) ?></p>
                <p><strong>Date Disposed:</strong> <?= date('M d, Y', strtotime($d['disposal_date'])) ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </ul>
      </div>

    </div>
  </main>
</div>
<script src="script.js" defer></script>
</body>
</html>
