<?php
session_start();
include 'db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();

// Fixed: Get request_type_id from request_supply and join with request_type table, added quantity
$sql = "SELECT rs.request_id, rs.request_date, rs.status, rs.office, rs.description, rs.request_type_id, rs.quantity,
               rt.type_name,
               GROUP_CONCAT(e.equipment_name SEPARATOR ', ') as equipment_names
        FROM request_supply rs
        LEFT JOIN request_type rt ON rs.request_type_id = rt.request_type_id
        LEFT JOIN equipment e ON e.request_id = rs.request_id
        WHERE rs.user_id = ?
        GROUP BY rs.request_id
        ORDER BY rs.request_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$requests = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$equipment_sql = "SELECT equipment_name FROM equipment WHERE status='Available'";
$equipment_result = $conn->query($equipment_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Request</title>
<link rel="stylesheet" href="style/request.css">
</head>
<body class="request-page">

<div class="dashboard-container">
  <header class="topbar">
    <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
    <h1>Equipment Request</h1>
    <div class="user-info">
      <img src="compartment/user.png" alt="User" class="user-icon">
      <span><?= htmlspecialchars($user_name) ?></span>
    </div>
  </header>

  <aside class="sidebar">
    <ul>
      <li><a href="user_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
      <li><a href="user_request.php" class="active"><img src="compartment/request.png" alt="Request"> <span>Request</span></a></li>
      <li><a href="user_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
      <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
    </ul>
  </aside>

  <main class="content">
    <div class="form-container">
      <h2>St. Michael's College Equipment Request Form</h2>

      <?php if(isset($_SESSION['success'])): ?>
        <p class="success-msg"><?= htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></p>
      <?php elseif(isset($_SESSION['error'])): ?>
        <p class="error-msg"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></p>
      <?php endif; ?>

      <button id="openFormModal" class="submit-btn">+ New Request</button>

      <div id="requestModal" class="modal">
        <div class="modal-content">
          <span class="close" data-modal="requestModal">&times;</span>
          <h2>Equipment Request Form</h2>

          <form id="equipmentForm" method="POST" action="submit_request.php">
            <label for="name">Name *</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($user_name) ?>" readonly>

            <label for="office">Office *</label>
            <select id="office" name="office" required>
              <option value="">-- Select Office --</option>
              <?php
                $offices = ['Research Office','Dean\'s Office','ICTC','Clinic','Library','HR','Canteen','DSA','MICSR','Guidance'];
                foreach($offices as $office) {
                  echo "<option value='".htmlspecialchars($office)."'>".htmlspecialchars($office)."</option>";
                }
              ?>
            </select>

            <div id="deansChecklist" style="display:none; margin-top:10px;">
              <strong>Select Dean's Sub-Office:</strong><br>
              <?php
                $deans = ['CCS','CAS','CED','COE','CON','CBAA','CHTM','COC'];
                foreach($deans as $d) echo "<label><input type='checkbox' name='deans[]' value='".htmlspecialchars($d)."'> ".htmlspecialchars($d)."</label><br>";
              ?>
            </div>

            <label for="requestType">Request Type *</label>
            <select id="requestType" name="requestType" required>
              <option value="">-- Select Type --</option>
              <?php
                $types = ['Borrow','Purchase','Repair','Maintenance'];
                foreach($types as $type) echo "<option value='".htmlspecialchars($type)."'>".htmlspecialchars($type)."</option>";
              ?>
            </select>

            <select id="availableEquipment" name="availableEquipment">
              <option value="">-- Select Equipment --</option>
              <?php while($eq = $equipment_result->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($eq['equipment_name']) ?>"><?= htmlspecialchars($eq['equipment_name']) ?></option>
              <?php endwhile; ?>
            </select>

            <label for="description">Description *</label>
            <textarea id="description" name="description" rows="3" required></textarea>

            <label for="dateRequested">Date Requested *</label>
            <input type="date" id="dateRequested" name="dateRequested" required>

            <label for="quantity">Quantity *</label>
            <input type="number" id="quantity" name="quantity" min="1" required>

            <div class="form-buttons">
              <button type="button" class="cancel-btn">Cancel</button>
              <button type="submit" class="submit-btn">Submit</button>
            </div>
          </form>
        </div>
      </div>

      <button class="accordion">Request History</button>
      <div class="panel">
        <div id="historyFilters">
          <label for="filterDate">Date:</label>
          <input type="month" id="filterDate">

          <label for="filterStatus">Status:</label>
          <select id="filterStatus">
            <option value="all">All</option>
            <option value="Pending">Pending</option>
            <option value="Approved by President">Approved by President</option>
            <option value="Approved by VP">Approved by VP</option>
            <option value="Rejected">Rejected</option>
          </select>
          <button id="applyFilter">Apply</button>
        </div>

        <ul id="historyList">
          <?php if(empty($requests)): ?>
            <li style="list-style: none; text-align: center; padding: 20px; color: #666;">
              No request history found.
            </li>
          <?php else: ?>
            <?php foreach($requests as $req): ?>
              <li data-date="<?= date('Y-m', strtotime($req['request_date'])) ?>" data-status="<?= htmlspecialchars($req['status']) ?>">
                <span>
                  <strong><?= htmlspecialchars($user_name) ?></strong> - 
                  <?= htmlspecialchars($req['type_name'] ?? 'N/A') ?>: 
                  <?= htmlspecialchars($req['equipment_names'] ?: $req['description']) ?> 
                  (Qty: <?= htmlspecialchars($req['quantity']) ?>) 
                  (<?= date('M d, Y', strtotime($req['request_date'])) ?>) - 
                  <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $req['status'])) ?>">
                    <?= htmlspecialchars($req['status']) ?>
                  </span>
                </span>
                <button class="view-btn" data-modal="reportModal<?= $req['request_id'] ?>">View</button>
              </li>

              <div id="reportModal<?= $req['request_id'] ?>" class="modal">
                <div class="modal-content">
                  <span class="close" data-modal="reportModal<?= $req['request_id'] ?>">&times;</span>
                  <h2>Request Details</h2>
                  <p><strong>Request ID:</strong> #<?= htmlspecialchars($req['request_id']) ?></p>
                  <p><strong>Name:</strong> <?= htmlspecialchars($user_name) ?></p>
                  <p><strong>Office:</strong> <?= htmlspecialchars($req['office']) ?></p>
                  <p><strong>Request Type:</strong> <?= htmlspecialchars($req['type_name'] ?? 'N/A') ?></p>
                  <p><strong>Equipment:</strong> <?= htmlspecialchars($req['equipment_names'] ?: 'N/A') ?></p>
                  <p><strong>Description:</strong> <?= htmlspecialchars($req['description']) ?></p>
                  <p><strong>Quantity:</strong> <?= htmlspecialchars($req['quantity']) ?></p>
                  <p><strong>Status:</strong> 
                    <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $req['status'])) ?>">
                      <?= htmlspecialchars($req['status']) ?>
                    </span>
                  </p>
                  <p><strong>Date Requested:</strong> <?= date('F d, Y', strtotime($req['request_date'])) ?></p>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </ul>
      </div>

    </div>
  </main>
</div>

<script src="script.js" defer></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const equipmentSelect = document.getElementById('availableEquipment');
    const descriptionField = document.getElementById('description');
    
    if (equipmentSelect && descriptionField) {
        equipmentSelect.addEventListener('change', function() {
            if (this.value) {
                // Auto-fill description with selected equipment
                descriptionField.value = this.value;
            }
        });
    }
});
</script>
</body>
</html>