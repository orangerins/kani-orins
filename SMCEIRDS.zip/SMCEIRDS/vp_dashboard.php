<?php
session_start();
include 'db_connect.php';

// Check if user is logged in and has VP-Finance role
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username']) || $_SESSION['role'] != 'VP-Finance') {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Initialize counters
$pending_vp = 0;
$approved_vp = 0;
$declined = 0;
$total_stocks = 0;

// Count requests pending VP approval (approved by President, waiting for VP)
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM request WHERE status = 'Approved by President'");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$pending_vp = $row['count'];
$stmt->close();

// Count requests approved by VP (final approval)
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM request WHERE status = 'Approved by VP Finance'");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$approved_vp = $row['count'];
$stmt->close();

// Count rejected requests
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM request WHERE status = 'Rejected'");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$declined = $row['count'];
$stmt->close();

// Count total available equipment/stocks
$stmt = $conn->prepare("SELECT SUM(quantity) as total FROM equipment WHERE status IN ('Available', 'In Use')");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_stocks = $row['total'] ?? 0;
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vice President Finance Dashboard</title>
  <link rel="stylesheet" href="style/vp_finance_dashboard.css">
</head>
<body class="dashboard-page">

  <div class="dashboard-container">

    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Vice President Finance - Dashboard</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="Vice President" class="user-icon">
        <span><?= htmlspecialchars($username) ?></span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="vp_dashboard.php" class="active"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="vp_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
        <li><a href="vp_inventory.php"><img src="compartment/inventory.png" alt="Inventory"> <span>Inventory</span></a></li>
        <li><a href="vp_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Overview</h2>
      <div class="cards">
        <div class="card pending">
          <h3>Pending for VP Review</h3>
          <p><?= $pending_vp ?></p>
        </div>
        <div class="card approved">
          <h3>Approved by VP</h3>
          <p><?= $approved_vp ?></p>
        </div>
        <div class="card declined">
          <h3>Rejected Requests</h3>
          <p><?= $declined ?></p>
        </div>
        <div class="card inventory">
          <h3>Total Stocks</h3>
          <p><?= $total_stocks ?></p>
        </div>
      </div>
    </main>

  </div>

</body>
</html>