<?php
session_start();
include 'db_connect.php';

// Check if user is logged in and has VP-Finance role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'VP-Finance') {
    header('Location: login.php');
    exit;
}

// Handle AJAX requests
if (isset($_POST['action']) || isset($_GET['action'])) {
    $action = isset($_POST['action']) ? $_POST['action'] : $_GET['action'];
    
    switch($action) {
        case 'load_equipment_history':
            loadEquipmentHistory($conn);
            exit;
        case 'filter_equipment_history':
            filterEquipmentHistory($conn);
            exit;
    }
}

function loadEquipmentHistory($conn) {
    try {
        $sql = "SELECT 
                    r.request_id,
                    r.description as equipment_name,
                    u.username as requested_by,
                    o.office_name,
                    r.request_date,
                    r.status as request_status,
                    rt.type_name as request_type,
                    ri.quantity
                FROM request r
                LEFT JOIN users u ON r.user_id = u.user_id
                LEFT JOIN office o ON u.office_id = o.office_id
                LEFT JOIN request_type rt ON r.request_type_id = rt.request_type_id
                LEFT JOIN request_item ri ON r.request_id = ri.request_id
                WHERE r.status IN ('Approved by President', 'Approved by VP Finance')
                ORDER BY r.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          ($row['equipment_name'] ?? 'N/A') . "~" . 
                          ($row['requested_by'] ?? 'Unknown') . "~" . 
                          ($row['office_name'] ?? 'Unknown') . "~" . 
                          $row['request_date'] . "~" . 
                          $row['request_status'] . "~" . 
                          ($row['request_type'] ?? 'Unknown') . "~" . 
                          ($row['quantity'] ?? '0');
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to load equipment history: " . $e->getMessage();
    }
}

function filterEquipmentHistory($conn) {
    try {
        $status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
        $date_filter = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
        $type_filter = isset($_GET['type']) ? mysqli_real_escape_string($conn, $_GET['type']) : 'all';
        
        $sql = "SELECT 
                    r.request_id,
                    r.description as equipment_name,
                    u.username as requested_by,
                    o.office_name,
                    r.request_date,
                    r.status as request_status,
                    rt.type_name as request_type,
                    ri.quantity
                FROM request r
                LEFT JOIN users u ON r.user_id = u.user_id
                LEFT JOIN office o ON u.office_id = o.office_id
                LEFT JOIN request_type rt ON r.request_type_id = rt.request_type_id
                LEFT JOIN request_item ri ON r.request_id = ri.request_id
                WHERE r.status IN ('Approved by President', 'Approved by VP Finance')";
        
        // Add status filter
        if($status_filter != 'all') {
            $sql .= " AND r.status = '$status_filter'";
        }
        
        // Add date filter
        if(!empty($date_filter)) {
            $sql .= " AND DATE(r.request_date) = '$date_filter'";
        }
        
        // Add type filter
        if($type_filter != 'all') {
            $sql .= " AND rt.type_name = '$type_filter'";
        }
        
        $sql .= " ORDER BY r.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          ($row['equipment_name'] ?? 'N/A') . "~" . 
                          ($row['requested_by'] ?? 'Unknown') . "~" . 
                          ($row['office_name'] ?? 'Unknown') . "~" . 
                          $row['request_date'] . "~" . 
                          $row['request_status'] . "~" . 
                          ($row['request_type'] ?? 'Unknown') . "~" . 
                          ($row['quantity'] ?? '0');
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to filter equipment history: " . $e->getMessage();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VP Finance - Equipment Request History</title>
  <link rel="stylesheet" href="style/vp_finance_history.css">
</head>
<body class="vp-history-page">

  <div class="dashboard-container">

    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Vice President Finance - Equipment Request History</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="Vice President" class="user-icon">
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="vp_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li><a href="vp_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
        <li class="active"><a href="vp_inventory.php"><img src="compartment/inventory.png" alt="Inventory"> <span>Inventory</span></a></li>
        <li><a href="vp_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Equipment Request History</h2>
      
      <div class="history-controls">
        <div class="filter-container">
          <label for="statusFilter">Status:</label>
          <select id="statusFilter">
            <option value="all">All</option>
            <option value="Approved by President">Approved by President</option>
            <option value="Approved by VP Finance">Approved by VP Finance</option>
          </select>

          <label for="typeFilter">Request Type:</label>
          <select id="typeFilter">
            <option value="all">All Types</option>
            <option value="Borrow">Borrow</option>
            <option value="Purchase">Purchase</option>
            <option value="Repair">Repair</option>
            <option value="Maintenance">Maintenance</option>
          </select>

          <label for="dateFilter">Date:</label>
          <input type="date" id="dateFilter">
          
          <button id="applyFilter" class="btn">Apply Filter</button>
        </div>
        
        <div class="action-buttons">
          <a href="vp_inventory.php" class="btn" style="background-color: #6c757d; color: white; text-decoration: none;">Back to Inventory</a>
        </div>
      </div>

      <table class="history-table">
        <thead>
          <tr>
            <th>Request ID</th>
            <th>Equipment Name</th>
            <th>Requested By</th>
            <th>Office</th>
            <th>Request Type</th>
            <th>Quantity</th>
            <th>Date Requested</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="historyList">
          <tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">Loading equipment request history...</td></tr>
        </tbody>
      </table>
    </main>

  </div>

  <script src="script.js"></script>
</body>
</html>