<?php
session_start();
include 'db_connect.php';

// Check if user is logged in and has VP-Finance role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'VP-Finance') {
    header('Location: login.php');
    exit;
}

$logged_in_user_id = $_SESSION['user_id'];

// Handle AJAX requests
if (isset($_POST['action']) || isset($_GET['action'])) {
    $action = isset($_POST['action']) ? $_POST['action'] : $_GET['action'];
    
    switch($action) {
        case 'load':
            loadInventory($conn);
            exit;
        case 'add':
            addItem($conn, $logged_in_user_id);
            exit;
        case 'edit':
            editItem($conn, $logged_in_user_id);
            exit;
        case 'delete':
            deleteItem($conn);
            exit;
        case 'search':
            searchInventory($conn);
            exit;
    }
}

function loadInventory($conn) {
    try {
        $sql = "SELECT 
                    e.equipment_id,
                    e.equipment_name,
                    e.location,
                    e.status,
                    e.quantity,
                    u.username as user_name
                FROM equipment e
                LEFT JOIN users u ON e.user_id = u.user_id
                ORDER BY e.equipment_id DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result) {
            echo "success|";
            if(mysqli_num_rows($result) > 0) {
                $items = array();
                while($row = mysqli_fetch_assoc($result)) {
                    $items[] = $row['equipment_id'] . "~" . 
                              $row['equipment_name'] . "~" . 
                              ($row['user_id'] ?? 0) . "~" . 
                              ($row['user_name'] ?? 'System') . "~" . 
                              ($row['location'] ?? 'N/A') . "~" .
                              $row['status'] . "~" . 
                              $row['quantity'];
                }
                echo implode("|", $items);
            }
        } else {
            echo "error|Failed to load inventory: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Database error: " . $e->getMessage();
    }
}

function addItem($conn, $logged_in_user_id) {
    try {
        $equipment_name = mysqli_real_escape_string($conn, trim($_POST['equipment_name']));
        $location = mysqli_real_escape_string($conn, trim($_POST['location']));
        $status = mysqli_real_escape_string($conn, trim($_POST['status']));
        $quantity = intval($_POST['quantity']);
        $user_id = $logged_in_user_id;
        
        if(empty($equipment_name) || empty($status) || $quantity <= 0) {
            echo "error|All fields are required and quantity must be greater than 0";
            return;
        }
        
        $valid_statuses = ['Available', 'In Use', 'Damaged', 'Disposed'];
        if(!in_array($status, $valid_statuses)) {
            echo "error|Invalid status value";
            return;
        }
        
        $sql = "INSERT INTO equipment (equipment_name, location, user_id, status, quantity) 
                VALUES ('$equipment_name', '$location', $user_id, '$status', $quantity)";
        
        if(mysqli_query($conn, $sql)) {
            echo "success|Item added successfully";
        } else {
            echo "error|Failed to add item: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Database error: " . $e->getMessage();
    }
}

function editItem($conn, $logged_in_user_id) {
    try {
        $equipment_id = intval($_POST['equipment_id']);
        $equipment_name = mysqli_real_escape_string($conn, trim($_POST['equipment_name']));
        $location = mysqli_real_escape_string($conn, trim($_POST['location']));
        $status = mysqli_real_escape_string($conn, trim($_POST['status']));
        $quantity = intval($_POST['quantity']);
        $user_id = $logged_in_user_id;
        
        if($equipment_id <= 0 || empty($equipment_name) || empty($status) || $quantity <= 0) {
            echo "error|All fields are required and quantity must be greater than 0";
            return;
        }
        
        $valid_statuses = ['Available', 'In Use', 'Damaged', 'Disposed'];
        if(!in_array($status, $valid_statuses)) {
            echo "error|Invalid status value";
            return;
        }
        
        $check_sql = "SELECT equipment_id FROM equipment WHERE equipment_id = $equipment_id";
        $check_result = mysqli_query($conn, $check_sql);
        
        if(!$check_result || mysqli_num_rows($check_result) == 0) {
            echo "error|Equipment not found";
            return;
        }
        
        $sql = "UPDATE equipment 
                SET equipment_name = '$equipment_name',
                    location = '$location',
                    user_id = $user_id, 
                    status = '$status', 
                    quantity = $quantity 
                WHERE equipment_id = $equipment_id";
        
        if(mysqli_query($conn, $sql)) {
            echo "success|Item updated successfully";
        } else {
            echo "error|Failed to update item: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Database error: " . $e->getMessage();
    }
}

function deleteItem($conn) {
    try {
        $equipment_id = intval($_POST['equipment_id']);
        
        if($equipment_id <= 0) {
            echo "error|Invalid equipment ID";
            return;
        }
        
        $check_sql = "SELECT equipment_id, equipment_name FROM equipment WHERE equipment_id = $equipment_id";
        $check_result = mysqli_query($conn, $check_sql);
        
        if(!$check_result || mysqli_num_rows($check_result) == 0) {
            echo "error|Equipment not found";
            return;
        }
        
        $sql = "DELETE FROM equipment WHERE equipment_id = $equipment_id";
        
        if(mysqli_query($conn, $sql)) {
            echo "success|Item deleted successfully";
        } else {
            echo "error|Failed to delete item: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Database error: " . $e->getMessage();
    }
}

function searchInventory($conn) {
    try {
        $search_term = mysqli_real_escape_string($conn, trim($_GET['search']));
        
        if(empty($search_term)) {
            loadInventory($conn);
            return;
        }
        
        $sql = "SELECT 
                    e.equipment_id,
                    e.equipment_name,
                    e.location,
                    e.status,
                    e.quantity,
                    u.username as user_name
                FROM equipment e
                LEFT JOIN users u ON e.user_id = u.user_id
                WHERE e.equipment_name LIKE '%$search_term%' 
                   OR e.location LIKE '%$search_term%'
                   OR e.status LIKE '%$search_term%'
                   OR u.username LIKE '%$search_term%'
                ORDER BY e.equipment_id DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result) {
            echo "success|";
            if(mysqli_num_rows($result) > 0) {
                $items = array();
                while($row = mysqli_fetch_assoc($result)) {
                    $items[] = $row['equipment_id'] . "~" . 
                              $row['equipment_name'] . "~" . 
                              ($row['user_id'] ?? 0) . "~" . 
                              ($row['user_name'] ?? 'System') . "~" . 
                              ($row['location'] ?? 'N/A') . "~" .
                              $row['status'] . "~" . 
                              $row['quantity'];
                }
                echo implode("|", $items);
            }
        } else {
            echo "error|Search failed: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        echo "error|Search error: " . $e->getMessage();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vice President Finance - Inventory</title>
  <link rel="stylesheet" href="style/vp_finance_inventory.css">
</head>
<body class="vp-inventory-page">

  <div class="dashboard-container">

    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Vice President Finance - Inventory</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="Vice President" class="user-icon">
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
      </div>
    </header>

    <aside class="sidebar">
        <ul>
            <li><a href="vp_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
            <li><a href="vp_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
            <li class="active"><a href="vp_inventory.php"><img src="compartment/inventory.png" alt="Inventory"> <span>Inventory</span></a></li>
            <li><a href="vp_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
            <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
        </ul>
    </aside>

    <main class="content">
      <h2>Inventory Overview</h2>

      <div class="inventory-controls">
        <div class="button-group">
          <button id="addItemBtn" class="btn add">+ Add Item</button>
          <a href="vp_history.php" class="btn" style="background-color: #17a2b8; color: white; margin-left: 10px; text-decoration: none; display: inline-block; padding: 10px 15px; border-radius: 4px;">View Equipment History</a>
        </div>
        <div class="search-container">
          <input type="text" id="searchInput" placeholder="Search inventory..." class="search-input">
        </div>
      </div>

      <table class="inventory-table">
        <thead>
          <tr>
            <th>Item ID</th>
            <th>Item Name</th>
            <th>Location</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="inventoryList">
          <tr><td colspan="6" style="text-align: center; padding: 40px; color: #666;">Loading inventory...</td></tr>
        </tbody>
      </table>
    </main>

  </div>

  <!-- Add Item Modal -->
  <div id="addModal" class="modal">
    <div class="modal-content">
      <span class="close" data-close="addModal">&times;</span>
      <h3>Add New Item</h3>
      <form id="addForm">
        <label for="addItemName">Item Name:</label>
        <input type="text" id="addItemName" required>
        
        <label for="addLocation">Location:</label>
        <input type="text" id="addLocation" placeholder="e.g., Room 101, Storage A" required>
        
        <label for="addQuantity">Quantity:</label>
        <input type="number" id="addQuantity" min="1" required>
        
        <label for="addStatus">Status:</label>
        <select id="addStatus" required>
          <option value="">Select Status</option>
          <option value="Available">Available</option>
          <option value="In Use">In Use</option>
          <option value="Damaged">Damaged</option>
          <option value="Disposed">Disposed</option>
        </select>
        
        <div class="form-actions">
          <button type="submit" class="btn">Add Item</button>
          <button type="button" class="btn cancel" onclick="closeModal('addModal')">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Edit Item Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content">
      <span class="close" data-close="editModal">&times;</span>
      <h3>Edit Item</h3>
      <form id="editForm">
        <input type="hidden" id="editIndex">
        <input type="hidden" id="editEquipmentId">
        
        <label for="editItemId">Item ID:</label>
        <input type="text" id="editItemId" readonly>
        
        <label for="editItemName">Item Name:</label>
        <input type="text" id="editItemName" required>
        
        <label for="editLocation">Location:</label>
        <input type="text" id="editLocation" required>
        
        <label for="editQuantity">Quantity:</label>
        <input type="number" id="editQuantity" min="1" required>
        
        <label for="editStatus">Status:</label>
        <select id="editStatus" required>
          <option value="Available">Available</option>
          <option value="In Use">In Use</option>
          <option value="Damaged">Damaged</option>
          <option value="Disposed">Disposed</option>
        </select>
        
        <div class="form-actions">
          <button type="submit" class="btn">Save Changes</button>
          <button type="button" class="btn cancel" onclick="closeModal('editModal')">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Pass logged-in user ID to JavaScript -->
  <script>
    const LOGGED_IN_USER_ID = <?php echo $logged_in_user_id; ?>;
  </script>
  
  <script src="script.js"></script>
  <script>
  // Initialize VP Inventory page when DOM is ready
  document.addEventListener("DOMContentLoaded", () => {
      console.log('Initializing VP Finance Inventory page...');
      console.log('Logged-in user ID:', LOGGED_IN_USER_ID);
      
      // Load inventory data
      loadInventory();
      
      // Setup Add Item button
      const addItemBtn = document.getElementById('addItemBtn');
      if (addItemBtn) {
          addItemBtn.addEventListener('click', () => {
              openModal('addModal');
          });
      }
      
      // Setup Add Form
      const addForm = document.getElementById('addForm');
      if (addForm) {
          addForm.addEventListener('submit', (e) => {
              e.preventDefault();
              const itemData = {
                  name: document.getElementById('addItemName').value,
                  location: document.getElementById('addLocation').value,
                  status: document.getElementById('addStatus').value,
                  quantity: document.getElementById('addQuantity').value
              };
              addItem(itemData);
              addForm.reset();
          });
      }
      
      // Setup Edit Form
      const editForm = document.getElementById('editForm');
      if (editForm) {
          editForm.addEventListener('submit', (e) => {
              e.preventDefault();
              const itemData = {
                  name: document.getElementById('editItemName').value,
                  location: document.getElementById('editLocation').value,
                  status: document.getElementById('editStatus').value,
                  quantity: document.getElementById('editQuantity').value
              };
              const equipment_id = document.getElementById('editEquipmentId').value;
              editItem(itemData, equipment_id);
          });
      }
      
      // Setup Search
      const searchInput = document.getElementById('searchInput');
      if (searchInput) {
          let searchTimeout;
          searchInput.addEventListener('input', (e) => {
              clearTimeout(searchTimeout);
              searchTimeout = setTimeout(() => {
                  searchInventory(e.target.value);
              }, 300);
          });
      }
      
      console.log('VP Finance Inventory page initialized');
  });
  </script>
</body>
</html>