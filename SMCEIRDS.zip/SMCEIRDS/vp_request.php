<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'VP-Finance') {
    header('Location: login.php');
    exit;
}

// Handle AJAX requests
if (isset($_POST['action']) || isset($_GET['action'])) {
    $action = isset($_POST['action']) ? $_POST['action'] : $_GET['action'];
    
    switch($action) {
        case 'load_requests':
            loadRequests($conn);
            exit;
        case 'filter_requests':
            filterRequests($conn);
            exit;
    }
}

function loadRequests($conn) {
    try {
        // VP Finance sees requests that have been approved by President
        $sql = "SELECT 
                    r.request_id,
                    rt.type_name as request_type,
                    u.username,
                    o.office_name,
                    r.request_date,
                    r.status,
                    r.description
                FROM request r
                JOIN users u ON r.user_id = u.user_id
                JOIN office o ON u.office_id = o.office_id
                JOIN request_type rt ON r.request_type_id = rt.request_type_id
                WHERE r.status IN ('Approved by President', 'Approved by VP Finance', 'Rejected')
                ORDER BY r.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          $row['request_type'] . "~" . 
                          $row['username'] . "~" . 
                          $row['office_name'] . "~" . 
                          $row['request_date'] . "~" . 
                          $row['status'] . "~" . 
                          $row['description'];
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to load requests: " . $e->getMessage();
    }
}

function filterRequests($conn) {
    try {
        $status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
        $date_filter = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
        
        $sql = "SELECT 
                    r.request_id,
                    rt.type_name as request_type,
                    u.username,
                    o.office_name,
                    r.request_date,
                    r.status,
                    r.description
                FROM request r
                JOIN users u ON r.user_id = u.user_id
                JOIN office o ON u.office_id = o.office_id
                JOIN request_type rt ON r.request_type_id = rt.request_type_id
                WHERE r.status IN ('Approved by President', 'Approved by VP Finance', 'Rejected')";
        
        // Add status filter
        if($status_filter != 'all') {
            if($status_filter == 'pending') {
                $sql .= " AND r.status = 'Approved by President'";
            } elseif($status_filter == 'approved') {
                $sql .= " AND r.status = 'Approved by VP Finance'";
            } elseif($status_filter == 'rejected') {
                $sql .= " AND r.status = 'Rejected'";
            } else {
                $sql .= " AND r.status = '$status_filter'";
            }
        }
        
        // Add date filter
        if(!empty($date_filter)) {
            $sql .= " AND DATE(r.request_date) = '$date_filter'";
        }
        
        $sql .= " ORDER BY r.request_date DESC";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            echo "success|";
            $items = array();
            while($row = mysqli_fetch_assoc($result)) {
                $items[] = $row['request_id'] . "~" . 
                          $row['request_type'] . "~" . 
                          $row['username'] . "~" . 
                          $row['office_name'] . "~" . 
                          $row['request_date'] . "~" . 
                          $row['status'] . "~" . 
                          $row['description'];
            }
            echo implode("|", $items);
        } else {
            echo "success|";
        }
    } catch (Exception $e) {
        echo "error|Failed to filter requests: " . $e->getMessage();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vice President Finance - Requests</title>
  <link rel="stylesheet" href="style/vp_finance_request.css">
</head>
<body class="vp-request-page">

  <div class="dashboard-container">

    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Vice President Finance - Requests</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="Vice President" class="user-icon">
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
      </div>
    </header>

    <aside class="sidebar">
      <ul>
        <li><a href="vp_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
        <li class="active"><a href="vp_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
        <li><a href="vp_inventory.php"><img src="compartment/inventory.png" alt="Inventory"> <span>Inventory</span></a></li>
        <li><a href="vp_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
        <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
      </ul>
    </aside>

    <main class="content">
      <h2>Requests for VP Finance Review</h2>
      
      <div class="filter-container">
        <label for="statusFilter">Status:</label>
        <select id="statusFilter">
          <option value="all">All</option>
          <option value="pending">Pending (From President)</option>
          <option value="approved">Approved by VP Finance</option>
          <option value="rejected">Rejected</option>
        </select>

        <label for="dateFilter">Date:</label>
        <input type="date" id="dateFilter">
      </div>

      <table class="request-table">
        <thead>
          <tr>
            <th>Request ID</th>
            <th>User</th>
            <th>Office</th>
            <th>Type</th>
            <th>Description</th>
            <th>Date Submitted</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="vpRequestList">
          <tr><td colspan="8" style="text-align: center; padding: 40px; color: #666;">Loading requests...</td></tr>
        </tbody>
      </table>
    </main>

  </div>

  <script src="script.js"></script>
</body>
</html>