<?php
session_start();
include 'db_connect.php';

// Check if user is logged in and has VP-Finance role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'VP-Finance') {
    header('Location: login.php');
    exit;
}

$logged_in_user_id = $_SESSION['user_id'];

// Handle AJAX requests
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    
    switch($action) {
        case 'get_request_details':
            getRequestDetails($conn);
            exit;
        case 'update_request_status':
            updateRequestStatus($conn, $logged_in_user_id);
            exit;
    }
}

function getRequestDetails($conn) {
    try {
        $request_id = intval($_POST['request_id']);
        
        if($request_id <= 0) {
            echo "error|Invalid request ID";
            return;
        }
        
        $sql = "SELECT 
                    r.request_id,
                    rt.type_name as request_type,
                    u.username,
                    o.office_name,
                    r.request_date,
                    r.status,
                    r.description,
                    ri.quantity
                FROM request r
                JOIN users u ON r.user_id = u.user_id
                JOIN office o ON u.office_id = o.office_id
                JOIN request_type rt ON r.request_type_id = rt.request_type_id
                LEFT JOIN request_item ri ON r.request_id = ri.request_id
                WHERE r.request_id = $request_id";
        
        $result = mysqli_query($conn, $sql);
        
        if($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            
            // Extract equipment name from description
            $equipment_display = 'Not specified';
            $description = $row['description'];
            
            // Search for equipment name in description
            $equip_sql = "SELECT equipment_name FROM equipment ORDER BY LENGTH(equipment_name) DESC";
            $equip_result = mysqli_query($conn, $equip_sql);
            
            while($equip_row = mysqli_fetch_assoc($equip_result)) {
                if(stripos($description, $equip_row['equipment_name']) !== false) {
                    $equipment_display = $equip_row['equipment_name'];
                    break;
                }
            }
            
            echo "success|" . 
                 $row['request_id'] . "~" . 
                 $row['request_type'] . "~" . 
                 $row['username'] . "~" . 
                 $row['office_name'] . "~" . 
                 $row['request_date'] . "~" . 
                 $row['status'] . "~" . 
                 $row['description'] . "~" . 
                 $equipment_display . "~" . 
                 ($row['quantity'] ?? '1');
        } else {
            echo "error|Request not found";
        }
    } catch (Exception $e) {
        echo "error|Failed to load request details: " . $e->getMessage();
    }
}

function updateRequestStatus($conn, $logged_in_user_id) {
    try {
        $request_id = intval($_POST['request_id']);
        $new_status = mysqli_real_escape_string($conn, trim($_POST['status']));
        
        if($request_id <= 0 || empty($new_status)) {
            echo "error|Invalid request data";
            return;
        }
        
        // Get request details
        $check_sql = "SELECT r.status, r.description, ri.quantity, rt.type_name
                      FROM request r 
                      JOIN request_type rt ON r.request_type_id = rt.request_type_id
                      LEFT JOIN request_item ri ON r.request_id = ri.request_id
                      WHERE r.request_id = $request_id";
        $check_result = mysqli_query($conn, $check_sql);
        $current_row = mysqli_fetch_assoc($check_result);
        
        if(!$current_row) {
            echo "error|Request not found";
            return;
        }
        
        $current_status = $current_row['status'];
        $request_type = $current_row['type_name'];
        $description = $current_row['description'];
        $requested_quantity = intval($current_row['quantity'] ?? 1);
        
        // VP Finance can only act on requests approved by President
        if($current_status != 'Approved by President') {
            echo "error|This request must be approved by President first";
            return;
        }
        
        // Valid status transitions for VP Finance
        $valid_statuses = ['Approved by VP Finance', 'Rejected'];
        if(!in_array($new_status, $valid_statuses)) {
            echo "error|Invalid status option";
            return;
        }
        
        // Begin transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Update request status
            $update_sql = "UPDATE request 
                          SET status = '$new_status' 
                          WHERE request_id = $request_id";
            
            if(!mysqli_query($conn, $update_sql)) {
                throw new Exception("Failed to update request status");
            }
            
            // If approved by VP Finance, handle inventory based on request type
            if($new_status == 'Approved by VP Finance') {
                
                if($requested_quantity <= 0) {
                    $requested_quantity = 1;
                }
                
                // Handle based on request type
                // BOTH BORROW AND PURCHASE subtract from inventory
                if($request_type == 'Borrow' || $request_type == 'Purchase') {
                    
                    // Get all available equipment, ordered by longest name first
                    $find_sql = "SELECT equipment_id, equipment_name, quantity 
                                FROM equipment 
                                WHERE status = 'Available'
                                ORDER BY LENGTH(equipment_name) DESC";
                    
                    $find_result = mysqli_query($conn, $find_sql);
                    $matched_equipment = null;
                    
                    // Search for equipment name within description
                    while($equip_row = mysqli_fetch_assoc($find_result)) {
                        if(stripos($description, $equip_row['equipment_name']) !== false) {
                            $matched_equipment = $equip_row;
                            break;
                        }
                    }
                    
                    if($matched_equipment) {
                        $existing_quantity = intval($matched_equipment['quantity']);
                        
                        if($existing_quantity >= $requested_quantity) {
                            // Subtract from existing inventory
                            $new_quantity = $existing_quantity - $requested_quantity;
                            
                            $update_equip_sql = "UPDATE equipment 
                                         SET quantity = $new_quantity,
                                             status = CASE 
                                                 WHEN $new_quantity = 0 THEN 'In Use'
                                                 ELSE status 
                                             END
                                         WHERE equipment_id = " . $matched_equipment['equipment_id'];
                            
                            if(!mysqli_query($conn, $update_equip_sql)) {
                                throw new Exception("Failed to update inventory: " . mysqli_error($conn));
                            }
                        } else {
                            throw new Exception("Insufficient inventory: Only {$existing_quantity} {$matched_equipment['equipment_name']} available, but {$requested_quantity} requested");
                        }
                    } else {
                        throw new Exception("No matching equipment found in inventory for the requested item");
                    }
                    
                } elseif($request_type == 'Repair' || $request_type == 'Maintenance') {
                    // REPAIR/MAINTENANCE: Just update request status, don't modify inventory
                }
            }
            
            // Commit transaction
            mysqli_commit($conn);
            echo "success|Request " . ($new_status == 'Approved by VP Finance' ? "approved" : "rejected") . " successfully";
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo "error|" . $e->getMessage();
        }
        
    } catch (Exception $e) {
        echo "error|Database error: " . $e->getMessage();
    }
}

// Get request ID from URL
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Review Request - VP Finance</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="vp-request-page">

  <div class="dashboard-container">

    <header class="topbar">
      <img src="compartment/logoname.png" alt="MySMC Logo" class="logo">
      <h1>Vice President Finance - Review Request</h1>
      <div class="user-info">
        <img src="compartment/user.png" alt="Vice President" class="user-icon">
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
      </div>
    </header>

    <aside class="sidebar">
        <ul>
            <li><a href="vp_dashboard.php"><img src="compartment/dashboard.png" alt="Dashboard"> <span>Dashboard</span></a></li>
            <li class="active"><a href="vp_request.php"><img src="compartment/request.png" alt="Requests"> <span>Requests</span></a></li>
            <li><a href="vp_inventory.php"><img src="compartment/inventory.png" alt="Inventory"> <span>Inventory</span></a></li>
            <li><a href="vp_disposal.php"><img src="compartment/disposal.png" alt="Disposal"> <span>Disposal</span></a></li>
            <li class="logout"><a href="login.php"><img src="compartment/logout.png" alt="Logout"> <span>Logout</span></a></li>
        </ul>
    </aside>

    <main class="content">
      <h2>Request Details</h2>
      
      <div class="request-details" id="requestDetailsContainer">
        <div style="text-align: center; padding: 40px; color: #666;">
          Loading request details...
        </div>
      </div>

      <div class="actions" id="actionsContainer" style="display: none;">
        <button class="btn approve" id="approveBtn">Approve</button>
        <button class="btn decline" id="rejectBtn">Reject</button>
        <a href="vp_request.php" class="btn" style="background-color: #6c757d; color: white; text-decoration: none;">Back</a>
      </div>
    </main>

  </div>

  <script>
    const REQUEST_ID = <?php echo $request_id; ?>;
    console.log('VP Finance Request ID:', REQUEST_ID);
  </script>
  <script src="script.js"></script>
</body>
</html>